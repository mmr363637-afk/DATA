#!/usr/bin/env python3
"""
Non-destructive registration patch for adding NeuroLab Studio to mmr363637-afk/DATA
(docs/lib/labs/labs-manifest.json) without touching Cardiac Simulator or PulmoLab.
"""
import json
import sys
from pathlib import Path

NEUROLAB_ENTRY = {
    "key": "neurolab",
    "name": "NeuroLab Studio | آزمایشگاه جامع نورولوژی بالینی",
    "nameEn": "NeuroLab Studio — Advanced Neurology Learning & Clinical Simulation Platform",
    "type": "modular-pwa",
    "theme": {"h": 245, "c": 76, "a": 192},
    "entry": "neurolab/index.html",
    "manifest": "neurolab/data/manifest.json",
    "counts": {
        "examDomains": 7,
        "cranialNerves": 12,
        "gaits": 8,
        "localizationSyndromes": 15,
        "neuroimagingScans": 36,
        "eegPatterns": 12,
        "neurophysPatterns": 8,
        "strokeEmergencies": 8,
        "diseases": 35,
        "diseaseCategories": 16,
        "cases": 8
    }
}

def patch_manifest(manifest_path: Path):
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    labs = data.get("labs", [])
    idx = next((i for i, x in enumerate(labs) if x.get("key") == "neurolab"), None)
    if idx is None:
        labs.append(NEUROLAB_ENTRY)
    else:
        labs[idx] = NEUROLAB_ENTRY
    data["labs"] = labs
    manifest_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Patched {manifest_path} cleanly ({len(labs)} labs registered).")

if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("content/labs/labs-manifest.json")
    patch_manifest(target)
