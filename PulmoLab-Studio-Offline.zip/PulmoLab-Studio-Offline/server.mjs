#!/usr/bin/env node
// PulmoLab Studio v2 — Live Preview Static Server (binds 0.0.0.0 for Arena Live Preview)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const CONTENT = path.join(ROOT, 'content');
const PORT = Number(process.env.PORT || 8090);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.wav': 'audio/wav',
  '.woff2': 'font/woff2'
};

const NO_STORE_HEADERS = {
  'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
  Pragma: 'no-cache',
  Expires: '0',
  'Access-Control-Allow-Origin': '*'
};

const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent((req.url || '/').split('?')[0]);

  if (urlPath === '/' || urlPath === '') {
    res.writeHead(302, { Location: '/labs/pulmolab/', ...NO_STORE_HEADERS });
    res.end();
    return;
  }

  // Redirect /labs/pulmolab (without trailing slash) so relative CSS/JS/data URLs resolve cleanly
  if (urlPath === '/labs/pulmolab') {
    res.writeHead(302, { Location: '/labs/pulmolab/', ...NO_STORE_HEADERS });
    res.end();
    return;
  }

  const normalized = path.normalize(urlPath).replace(/^(\.\.(\/|\\|$))+/, '');
  let fp = path.join(CONTENT, normalized);
  if (fs.existsSync(fp) && fs.statSync(fp).isDirectory()) {
    fp = path.join(fp, 'index.html');
  }

  if (!fp.startsWith(CONTENT) || !fs.existsSync(fp) || !fs.statSync(fp).isFile()) {
    console.warn(`[404] ${req.method} ${urlPath}`);
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', ...NO_STORE_HEADERS });
    res.end('404 Not Found');
    return;
  }

  const ext = path.extname(fp).toLowerCase();
  const stat = fs.statSync(fp);

  // Support HTTP Range requests for authentic WAV audio seeking
  const range = req.headers.range;
  if (range && ext === '.wav') {
    const [startStr, endStr] = range.replace(/bytes=/, '').split('-');
    const start = parseInt(startStr, 10) || 0;
    const end = endStr ? parseInt(endStr, 10) : stat.size - 1;
    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${stat.size}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': end - start + 1,
      'Content-Type': MIME[ext],
      ...NO_STORE_HEADERS
    });
    fs.createReadStream(fp, { start, end }).pipe(res);
    return;
  }

  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Content-Length': stat.size,
    'Accept-Ranges': 'bytes',
    ...NO_STORE_HEADERS
  });
  fs.createReadStream(fp).pipe(res);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`PulmoLab Studio v2 live preview running on http://0.0.0.0:${PORT}/labs/pulmolab/`);
});
