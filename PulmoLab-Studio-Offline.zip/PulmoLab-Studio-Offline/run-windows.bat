@echo off
chcp 65001 >nul
title PulmoLab Studio v4 - Offline Local Server
cd /d "%~dp0"
echo.
echo ========================================================
echo   PulmoLab Studio v4 - Starting Offline Local Server...
echo ========================================================
echo.
where node >nul 2>nul
if %errorlevel%==0 (
  start "" "http://127.0.0.1:8090/labs/pulmolab/"
  node server.mjs
  goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "" "http://127.0.0.1:8090/labs/pulmolab/"
  python -m http.server 8090 --directory content
  goto :eof
)
echo [!] Neither Node.js nor Python was found.
echo Tip: You can also use PulmoLab-Studio-Offline.html directly without any server!
pause
