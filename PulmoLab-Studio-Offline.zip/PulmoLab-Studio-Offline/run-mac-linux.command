#!/bin/bash
cd "$(dirname "$0")"
echo "PulmoLab Studio v4 — Starting Offline Local Server on http://127.0.0.1:8090/labs/pulmolab/ ..."
(sleep 1 && (open "http://127.0.0.1:8090/labs/pulmolab/" 2>/dev/null || xdg-open "http://127.0.0.1:8090/labs/pulmolab/" 2>/dev/null)) &
if command -v node >/dev/null 2>&1; then
  node server.mjs
elif command -v python3 >/dev/null 2>&1; then
  python3 -m http.server 8090 --directory content
else
  echo "Neither Node.js nor Python3 found. Open PulmoLab-Studio-Offline.html directly instead."
fi
