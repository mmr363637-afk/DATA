# بستهٔ ادغام با DATA — درس {SUBJECT}

## چه چیزی در بسته است
- `content/neurology/<slug>.html` — 14 درسنامهٔ کامل، آفلاین، با شناسهٔ استاندارد `neurology/<slug>`.
- `manifest.json` — چیدمان Planner: `id, title, subject, path, minutes, sections, words, flashcards, tables, mcq, source, appSubjectKeys`.
- `subject.json` — فرادادهٔ درس (کلید، زبان، راست‌به‌چپ، جمع واژه/زمان/سؤال، قرارداد نشانه‌گذاری).
- `slug-map.json` — نگاشت فصل به slug و به فایل مبدأ در `drafts/`.
- `contract-check.json` — نتیجهٔ سنجش: 14 فایل، 0 فایل دارای ایراد.

## نصب
۱. محتوای `content/` را در ریشهٔ محتوای DATA کپی کنید (پیش‌فرض: `content/neurology/`). مسیر در manifest هم همین است؛ اگر ساختار شما متفاوت است، فقط فیلد `path` را بازنویسی کنید.
۲. مدخل‌های `manifest.json` را به فایل چیدمان Planner اضافه کنید (آرایهٔ دروس) بدون تغییر کلیدها.
۳. اگر DATA فهرست درس‌ها را از فایل دستی می‌خواند، `subject.json` را در فهرست موضوعات ثبت کنید.
۴. هیچ CSS/JS بیرونی لازم نیست: هر فایل مستقل و آفلاین است و دارایی‌ها به‌صورت `data:` درون خود فایل‌اند.

## قرارداد فایل درس
- `.reader[data-lesson="neurology/<slug>"]` و `body[data-subject="neurology"]`, `data-subject-name`, `data-title`, `data-minutes`, `data-secs`.
- بخش‌ها: `main .sec[data-sec-id][data-sec-title]` با شناسه‌های یکتا؛ آخرین بخش با عنوان «شناسنامه درسنامه».
- آزمون: ۱۵ `.qx__q[data-answer]` با `.qx__sol`؛ کلید ۴|۴|۴|۳.
- فلش‌کارت: `.fx__q` / `.fx__a`.
- بلوک‌های گسترش: `.batch-review-addition` با یک سطر «صفحات کتاب» در هر بلوک.
- جست‌وجو، نشانک، علامت خوانده‌شدن و بزرگ‌نمایی تصویر درون همان فایل کار می‌کنند.

## محدودیت صریح
این بسته قرارداد ساختاری را برآورده می‌کند و آزمون مرورگر (۷۸۶ PASS / ۰ FAIL روی ۱۴ فایل در سه عرض، آفلاین) دارد؛ درستی علمی محتوا و کامل‌بودن نسبت به کتاب با این آزمون‌ها اثبات نمی‌شود.
